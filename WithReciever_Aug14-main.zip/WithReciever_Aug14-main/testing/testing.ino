#include <Firebase_ESP_Client.h>
#include <Wire.h>
#include <Arduino.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>
#include <WiFi.h>
#include <IRremoteESP8266.h>
#include <IRrecv.h>
#include <IRsend.h>
#include <time.h>
#include <Preferences.h>

#define OLED_SDA 21
#define OLED_SCL 22

#define WIFI_SSID "BA1D616R8"
#define WIFI_PASSWORD "GM6AA4X8rm128!"
#define DATABASE_SECRET "DvhZNBNmaFVHMFSup70ezVZlEVHWwO87OrGK4Td7"
#define DATABASE_URL "https://pcc-stats-default-rtdb.asia-southeast1.firebasedatabase.app/"

// CHANGE THIS TO YOUR ROOM ID (e.g., "Room_1", "Room_402", "Room_403", etc.)
#define ROOM_ID "Room_1"

// Set to true if this room has 2 AC units (requires 2 IR LEDs)
#define DUAL_UNIT_MODE true

const uint16_t kIrLedPin = 4;
const uint16_t kIrLedPin2 = 5;
const uint16_t kIrRecvPin = 14;
IRsend irsend(kIrLedPin);
IRsend irsend2(kIrLedPin2);
IRrecv irrecv(kIrRecvPin);
decode_results irResults;
const uint16_t kFrequency = 38;

// --- Koppel AC RAW Data (ON/OFF/TEMP_UP/TEMP_DOWN) ---
// Array sizes are NOT hardcoded - lengths are computed automatically below
// with sizeof(), so pasting in new raw codes here never mismatches the
// length used when sending them.
const uint16_t PROGMEM rawOn[] = {0, 2, 4904, 2470, 414, 370, 414, 396, 390, 378, 406, 926, 388, 918, 366, 418, 390, 394, 368, 430, 366, 414, 370, 940, 388, 374, 410, 398, 378, 416, 388, 918, 366, 420, 366, 430, 368, 412, 372, 418, 366, 938, 390, 410, 362, 414, 372, 938, 388, 374, 394, 426, 366, 418, 388, 916, 366, 940, 366, 426, 368, 938, 366, 420, 388, 372, 412, 408, 368, 418, 368, 418, 366, 418, 368, 430, 366, 418, 368, 418, 368, 418, 368, 428, 368, 418, 368, 418, 368, 418, 390, 406, 368, 418, 368, 418, 368, 418, 368, 428, 390, 0};
const uint16_t PROGMEM rawOff[] = {0, 2, 4908, 2466, 414, 396, 390, 396, 390, 394, 390, 926, 390, 916, 390, 396, 388, 396, 368, 430, 388, 398, 392, 912, 402, 382, 390, 406, 390, 394, 390, 916, 388, 396, 368, 430, 388, 396, 390, 394, 392, 914, 366, 428, 388, 396, 368, 938, 388, 396, 366, 428, 390, 396, 388, 916, 388, 916, 366, 428, 368, 938, 386, 398, 368, 418, 368, 428, 368, 418, 368, 418, 368, 418, 368, 430, 366, 418, 390, 374, 390, 418, 366, 430, 366, 418, 368, 418, 390, 374, 410, 408, 366, 418, 368, 418, 368, 418, 368, 430, 366, 0};
const uint16_t PROGMEM rawTempUp[] = {0, 2, 4908, 2488, 394, 370, 414, 370, 416, 372, 412, 922, 394, 912, 392, 372, 414, 372, 414, 380, 416, 370, 412, 914, 392, 370, 418, 382, 412, 368, 418, 910, 394, 368, 418, 380, 416, 910, 394, 368, 416, 916, 390, 380, 416, 370, 414, 914, 390, 370, 416, 380, 418, 368, 414, 912, 394, 910, 392, 380, 416, 914, 394, 368, 416, 368, 418, 378, 414, 370, 416, 370, 414, 370, 416, 380, 416, 372, 414, 370, 414, 372, 414, 380, 416, 372, 412, 370, 418, 368, 416, 382, 416, 370, 414, 372, 414, 370, 416, 378, 416, 0};
const uint16_t PROGMEM rawTempDown[] = {0, 2, 4888, 2486, 398, 376, 410, 370, 416, 370, 414, 920, 394, 910, 394, 372, 414, 370, 414, 382, 416, 370, 414, 910, 394, 370, 416, 380, 416, 370, 414, 910, 396, 370, 414, 380, 414, 910, 396, 370, 416, 908, 396, 380, 416, 370, 416, 908, 396, 370, 416, 380, 414, 370, 416, 906, 398, 906, 398, 380, 414, 906, 398, 392, 394, 390, 394, 400, 396, 390, 396, 390, 396, 390, 396, 400, 396, 390, 396, 392, 394, 392, 394, 402, 396, 372, 414, 370, 414, 372, 412, 384, 414, 372, 414, 372, 412, 374, 412, 384, 412, 0};

const int rawOnLen = sizeof(rawOn) / sizeof(rawOn[0]);
const int rawOffLen = sizeof(rawOff) / sizeof(rawOff[0]);
const int rawTempUpLen = sizeof(rawTempUp) / sizeof(rawTempUp[0]);
const int rawTempDownLen = sizeof(rawTempDown) / sizeof(rawTempDown[0]);

FirebaseData fbdo;
FirebaseData stream;
FirebaseAuth auth;
FirebaseConfig config;

Preferences preferences;

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

#define DHTPIN 26
#define DHTTYPE DHT22
#define LED_PIN 27
#define RELAY_PIN 25
DHT dht(DHTPIN, DHTTYPE);

float minTemp = 20.0;
float maxTemp = 30.0;
unsigned long sendDataPrevMillis = 0;

bool automationEnabled = false;  // Controls humidity-based automation
bool temperatureAutomationEnabled = true;  // Temperature safety always enabled

float MAX_HUMIDITY = 60.0;  // Default, will be updated from Firebase
float MIN_HUMIDITY = 45.0;  // Default, will be updated from Firebase
float humidityOccupiedThreshold = 60.0;  // From Firebase: automation/humidityOccupiedThreshold
float humidityEmptyThreshold = 45.0;     // From Firebase: automation/humidityEmptyThreshold
const unsigned long AUTOMATION_INTERVAL_MS = 300000; // 5 minutes between automation checks
const unsigned long STEP_PRESS_DELAY_MS = 400;
const unsigned long IR_SEND_COOLDOWN_MS = 60000; // 1 minute cooldown between IR sends
const unsigned long SERIAL_LOG_THROTTLE_MS = 5000; // 5 seconds between serial logs

unsigned long lastAutomationCheckMillis = 0;
unsigned long lastIRSendMillis = 0;
unsigned long lastSerialLogMillis = 0;

void handleACCommand(String cmd, int unit = 0);
void updateOLED(float currentTemp);
void runAutomation(float temp, float humidity);
void handleIRReceiver();

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("=== PCC S.T.A.T.S. System Starting ===");

  preferences.begin("pcc-automation", false);
  automationEnabled = preferences.getBool("automationEnabled", false);
  Serial.println("Loaded automation enabled state from Preferences: " + String(automationEnabled));

  Wire.begin(OLED_SDA, OLED_SCL);
  irsend.begin();
  irsend2.begin();
  irrecv.enableIRIn();
  Serial.println("[IR Receiver] IR receiver enabled on pin " + String(kIrRecvPin));

  pinMode(LED_PIN, OUTPUT);
  pinMode(RELAY_PIN, OUTPUT);
  dht.begin();

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    for (;;);
  }

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }

  configTime(8 * 3600, 0, "pool.ntp.org", "time.nist.gov");

  config.signer.tokens.legacy_token = DATABASE_SECRET;
  config.database_url = DATABASE_URL;
  Firebase.begin(&config, &auth);
  Firebase.reconnectWiFi(true);

  Serial.println("Setting up Firebase stream for: /" + String(ROOM_ID));
  if (!Firebase.RTDB.beginStream(&stream, "/" + String(ROOM_ID))) {
    Serial.println("Firebase stream failed: " + stream.errorReason());
  } else {
    Serial.println("Firebase stream started successfully");
    Serial.println("Stream path: /" + String(ROOM_ID));
  }

  Firebase.RTDB.getBool(&fbdo, "/" + String(ROOM_ID) + "/automation/enabled");
  if (fbdo.httpCode() == FIREBASE_ERROR_HTTP_CODE_OK) {
    automationEnabled = fbdo.boolData();
    preferences.putBool("automationEnabled", automationEnabled);
    Serial.println("Synced automation enabled state from Firebase: " + String(automationEnabled));
  }

  Firebase.RTDB.getFloat(&fbdo, "/" + String(ROOM_ID) + "/automation/humidityOccupiedThreshold");
  if (fbdo.httpCode() == FIREBASE_ERROR_HTTP_CODE_OK) {
    float threshold = fbdo.floatData();
    if (threshold > 0) {
      humidityOccupiedThreshold = threshold;
      MAX_HUMIDITY = threshold;
      Serial.println("Synced humidity occupied threshold from Firebase: " + String(humidityOccupiedThreshold) + "%");
    }
  }

  Firebase.RTDB.getFloat(&fbdo, "/" + String(ROOM_ID) + "/automation/humidityEmptyThreshold");
  if (fbdo.httpCode() == FIREBASE_ERROR_HTTP_CODE_OK) {
    float threshold = fbdo.floatData();
    if (threshold > 0) {
      humidityEmptyThreshold = threshold;
      MIN_HUMIDITY = threshold;
      Serial.println("Synced humidity empty threshold from Firebase: " + String(humidityEmptyThreshold) + "%");
    }
  }

  Firebase.RTDB.getFloat(&fbdo, "/" + String(ROOM_ID) + "/thresholds/minTemp");
  if (fbdo.httpCode() == FIREBASE_ERROR_HTTP_CODE_OK) {
    float temp = fbdo.floatData();
    if (temp > 0) {
      minTemp = temp;
      Serial.println("Synced minTemp from Firebase: " + String(minTemp) + "°C");
    }
  }

  Firebase.RTDB.getFloat(&fbdo, "/" + String(ROOM_ID) + "/thresholds/maxTemp");
  if (fbdo.httpCode() == FIREBASE_ERROR_HTTP_CODE_OK) {
    float temp = fbdo.floatData();
    if (temp > 0) {
      maxTemp = temp;
      Serial.println("Synced maxTemp from Firebase: " + String(maxTemp) + "°C");
    }
  }

  FirebaseJson json;
  json.set(".sv", "timestamp");
  Firebase.RTDB.setJSON(&fbdo, "/" + String(ROOM_ID) + "/last_seen", &json);
  Firebase.RTDB.setBool(&fbdo, "/" + String(ROOM_ID) + "/online", true);
  Firebase.RTDB.setString(&fbdo, "/" + String(ROOM_ID) + "/device_room_id", ROOM_ID);

  #if DUAL_UNIT_MODE
  Firebase.RTDB.setBool(&fbdo, "/" + String(ROOM_ID) + "/units/unit_1/ac", false);
  Firebase.RTDB.setBool(&fbdo, "/" + String(ROOM_ID) + "/units/unit_2/ac", false);
  Firebase.RTDB.setString(&fbdo, "/" + String(ROOM_ID) + "/units/unit_1/ac_command", "IDLE");
  Firebase.RTDB.setString(&fbdo, "/" + String(ROOM_ID) + "/units/unit_2/ac_command", "IDLE");
  #endif
}

void loop() {
  static unsigned long lastLoopLog = 0;
  if (millis() - lastLoopLog > 60000) {
    Serial.println("[Loop] ESP32 is running, millis: " + String(millis()));
    Serial.println("[Loop] Firebase ready: " + String(Firebase.ready() ? "YES" : "NO"));
    lastLoopLog = millis();
  }

    if (Firebase.ready() && Firebase.RTDB.readStream(&stream)) {
    if (stream.streamTimeout()) {
      return;
    }
    if (stream.dataType() == "null") {
      return;
    }
    
    String path = stream.dataPath();
    
    // Log important paths, ignore system paths like /last_seen
    if (path != "/last_seen" && path.indexOf("last_seen") < 0) {
      Serial.println("[Firebase] Path: " + path + ", Type: " + stream.dataType());
    }
    
    // Handle root path updates (entire room object)
    if (path == "/" && stream.dataType() == "json") {
      FirebaseJson &json = stream.jsonObject();
      FirebaseJsonData jsonData;
      if (json.get(jsonData, "ac_command")) {
        String cmd = jsonData.stringValue;
        Serial.println("[Firebase] Found ac_command in root object: " + cmd);
        if (cmd != "IDLE") {
          #if DUAL_UNIT_MODE
          Serial.println("[Firebase] Dual unit mode - sending to both units");
          handleACCommand(cmd, 1);
          handleACCommand(cmd, 2);
          #else
          Serial.println("[Firebase] Single unit mode - sending to unit 0");
          handleACCommand(cmd, 0);
          #endif
        } else {
          Serial.println("[Firebase] Ignoring IDLE command");
        }
      }
    }
    
    if (path == "/thresholds/minTemp" || path == "/minTemp") {
      minTemp = stream.floatData();
      Serial.println("[Firebase] Updated minTemp: " + String(minTemp));
    } else if (path == "/thresholds/maxTemp" || path == "/maxTemp") {
      maxTemp = stream.floatData();
      Serial.println("[Firebase] Updated maxTemp: " + String(maxTemp));
    } else if (path == "/automation/enabled" || path.indexOf("automation/enabled") >= 0) {
      bool newEnabledState = stream.boolData();
      if (newEnabledState != automationEnabled) {
        automationEnabled = newEnabledState;
        preferences.putBool("automationEnabled", automationEnabled);
        Serial.println("Humidity automation " + String(automationEnabled ? "ENABLED" : "DISABLED"));
      }
    } else if (path == "/automation" || path.indexOf("automation") >= 0) {
      FirebaseJson &json = stream.jsonObject();
      FirebaseJsonData jsonData;
      if (json.get(jsonData, "enabled")) {
        bool newEnabledState = jsonData.boolValue;
        if (newEnabledState != automationEnabled) {
          automationEnabled = newEnabledState;
          preferences.putBool("automationEnabled", automationEnabled);
          Serial.println("Humidity automation " + String(automationEnabled ? "ENABLED" : "DISABLED"));
        }
      }
      if (json.get(jsonData, "humidityOccupiedThreshold")) {
        float newThreshold = jsonData.floatValue;
        if (newThreshold > 0 && newThreshold != humidityOccupiedThreshold) {
          humidityOccupiedThreshold = newThreshold;
          MAX_HUMIDITY = newThreshold;
          Serial.println("Humidity occupied threshold updated: " + String(humidityOccupiedThreshold) + "%");
        }
      }
      if (json.get(jsonData, "humidityEmptyThreshold")) {
        float newThreshold = jsonData.floatValue;
        if (newThreshold > 0 && newThreshold != humidityEmptyThreshold) {
          humidityEmptyThreshold = newThreshold;
          MIN_HUMIDITY = newThreshold;
          Serial.println("Humidity empty threshold updated: " + String(humidityEmptyThreshold) + "%");
        }
      }
    } else if (path == "/automation/humidityOccupiedThreshold") {
      float newThreshold = stream.floatData();
      if (newThreshold > 0 && newThreshold != humidityOccupiedThreshold) {
        humidityOccupiedThreshold = newThreshold;
        MAX_HUMIDITY = newThreshold;
        Serial.println("Humidity occupied threshold updated: " + String(humidityOccupiedThreshold) + "%");
      }
    } else if (path == "/automation/humidityEmptyThreshold") {
      float newThreshold = stream.floatData();
      if (newThreshold > 0 && newThreshold != humidityEmptyThreshold) {
        humidityEmptyThreshold = newThreshold;
        MIN_HUMIDITY = newThreshold;
        Serial.println("Humidity empty threshold updated: " + String(humidityEmptyThreshold) + "%");
      }
    } else if (path == "/ac_command" || path.endsWith("ac_command")) {
      Serial.print("[Firebase] ac_command received - Path: "); Serial.print(path);
      Serial.print(", Command: "); Serial.println(stream.stringData());
      
      String cmd = stream.stringData();
      if (cmd == "IDLE") {
        Serial.println("[Firebase] Ignoring IDLE command");
        return;
      }
      
      Serial.println("[Firebase] Processing AC command: " + cmd);
      
      if (path.indexOf("/units/unit_1/") >= 0) {
        Serial.println("[Firebase] Routing to Unit 1");
        handleACCommand(cmd, 1);
      } else if (path.indexOf("/units/unit_2/") >= 0) {
        Serial.println("[Firebase] Routing to Unit 2");
        handleACCommand(cmd, 2);
      } else {
        Serial.println("[Firebase] Routing to Single Unit (unit 0)");
        handleACCommand(cmd, 0);
      }
    } else if (path == "/units/unit_1" || path == "/units/unit_1/") {
      Serial.println("[Firebase] Unit 1 object updated");
      FirebaseJson &json = stream.jsonObject();
      FirebaseJsonData jsonData;
      if (json.get(jsonData, "ac_command")) {
        String cmd = jsonData.stringValue;
        Serial.println("[Firebase] Found ac_command in Unit 1: " + cmd);
        if (cmd != "IDLE") {
          handleACCommand(cmd, 1);
        } else {
          Serial.println("[Firebase] Ignoring IDLE command");
        }
      }
    } else if (path == "/units/unit_2" || path == "/units/unit_2/") {
      Serial.println("[Firebase] Unit 2 object updated");
      FirebaseJson &json = stream.jsonObject();
      FirebaseJsonData jsonData;
      if (json.get(jsonData, "ac_command")) {
        String cmd = jsonData.stringValue;
        Serial.println("[Firebase] Found ac_command in Unit 2: " + cmd);
        if (cmd != "IDLE") {
          handleACCommand(cmd, 2);
        } else {
          Serial.println("[Firebase] Ignoring IDLE command");
        }
      }
    } else if (path == "/units/unit_1/targetTemp" || path.indexOf("/units/unit_1/targetTemp") >= 0) {
      Serial.println("[Firebase] Unit 1 targetTemp updated: " + String(stream.floatData()) + "°C");
      // Unit target temp update is handled by the ac_command sent separately
    } else if (path == "/units/unit_2/targetTemp" || path.indexOf("/units/unit_2/targetTemp") >= 0) {
      Serial.println("[Firebase] Unit 2 targetTemp updated: " + String(stream.floatData()) + "°C");
      // Unit target temp update is handled by the ac_command sent separately
    } else if (path == "/targetTemp" || path.indexOf("targetTemp") >= 0) {
      Serial.println("[Firebase] targetTemp updated: " + String(stream.floatData()) + "°C");
      // Target temp update is handled by the ac_command sent separately
    }
  }

  float t = dht.readTemperature();
  float h = dht.readHumidity();

  static unsigned long lastSensorLogMillis = 0;
  if (!isnan(t) && !isnan(h) && millis() - lastSensorLogMillis > 5000) {
    Serial.print("Live - Temp: "); Serial.print(t, 1); Serial.print("°C, Humidity: "); Serial.print(h, 1); Serial.println("%");
    lastSensorLogMillis = millis();
  }

  if (!isnan(t)) {
    bool isAlarm = (t < minTemp || t > maxTemp);
    digitalWrite(LED_PIN, isAlarm ? HIGH : LOW);
    digitalWrite(RELAY_PIN, (t < minTemp) ? LOW : HIGH);
  }

  updateOLED(t);

  handleIRReceiver();

  if (!isnan(t) && !isnan(h)) {
    runAutomation(t, h);
  }

  if (millis() - sendDataPrevMillis > 10000) {
    sendDataPrevMillis = millis();
    FirebaseJson updateData;
    updateData.add("temperature", t);
    updateData.add("humidity", h);
    updateData.add("status", (!isnan(t) && (t < minTemp || t > maxTemp)) ? "ALARM" : "NORMAL");
    Firebase.RTDB.updateNode(&fbdo, "/" + String(ROOM_ID), &updateData);

    FirebaseJson json;
    json.set(".sv", "timestamp");
    Firebase.RTDB.setJSON(&fbdo, "/" + String(ROOM_ID) + "/last_seen", &json);

    if (!isnan(t) && !isnan(h)) {
      time_t now = time(nullptr);
      struct tm* timeinfo = localtime(&now);
      char dateStr[11];
      char hourStr[3];
      strftime(dateStr, sizeof(dateStr), "%Y-%m-%d", timeinfo);
      strftime(hourStr, sizeof(hourStr), "%H", timeinfo);

      String historyPath = "/history/" + String(ROOM_ID) + "/" + String(dateStr) + "/" + String(hourStr);
      FirebaseJson historyData;
      historyData.add("temperature", t);
      historyData.add("humidity", h);
      Firebase.RTDB.setJSON(&fbdo, historyPath.c_str(), &historyData);
    }
  }
}

void updateOLED(float currentTemp) {
  display.clearDisplay();

  display.fillScreen(SSD1306_WHITE);
  display.setTextColor(SSD1306_BLACK);

  display.setTextSize(1);
  display.setCursor(5, 5);
  display.printf("SET: %.0fC - %.0fC", minTemp, maxTemp);

  display.drawFastHLine(0, 15, 128, SSD1306_BLACK);

  display.setCursor(20, 30);
  display.setTextSize(2);
  if (isnan(currentTemp)) {
    display.print("SENSOR ERR");
  } else {
    display.print(currentTemp, 1);
    display.print(" C");
  }

  display.setTextSize(1);
  display.setCursor(5, 55);
  if (isnan(currentTemp)) {
    display.print("STATUS: NO READING");
  } else if (currentTemp < minTemp) {
    display.print("STATUS: TOO COLD");
  } else if (currentTemp > maxTemp) {
    display.print("STATUS: TOO HOT");
  } else {
    display.print("STATUS: NORMAL");
  }

  display.display();
}

void handleACCommand(String cmd, int unit) {
  Serial.println("🎮 AC Command: " + cmd + " (Unit " + String(unit) + ")");
  
  IRsend *irSender = (unit == 1) ? &irsend2 : &irsend;
  uint16_t pin = (unit == 1) ? kIrLedPin2 : kIrLedPin;
  
  if (cmd == "ON") {
    uint16_t on_buf[rawOnLen];
    memcpy_P(on_buf, rawOn, sizeof(rawOn));
    irSender->sendRaw(on_buf, rawOnLen, kFrequency);
    Serial.println("✓ ON sent on pin " + String(pin));
  } else if (cmd == "OFF") {
    uint16_t off_buf[rawOffLen];
    memcpy_P(off_buf, rawOff, sizeof(rawOff));
    irSender->sendRaw(off_buf, rawOffLen, kFrequency);
    Serial.println("✓ OFF sent on pin " + String(pin));
  } else if (cmd == "TEMP_UP") {
    uint16_t up_buf[rawTempUpLen];
    memcpy_P(up_buf, rawTempUp, sizeof(rawTempUp));
    irSender->sendRaw(up_buf, rawTempUpLen, kFrequency);
    Serial.println("✓ TEMP_UP sent on pin " + String(pin));
  } else if (cmd == "TEMP_DOWN") {
    uint16_t down_buf[rawTempDownLen];
    memcpy_P(down_buf, rawTempDown, sizeof(rawTempDown));
    irSender->sendRaw(down_buf, rawTempDownLen, kFrequency);
    Serial.println("✓ TEMP_DOWN sent on pin " + String(pin));
  } else {
    Serial.println("⚠️ Unknown command: " + cmd);
    return;
  }

  // Update Firebase based on unit
  if (unit == 0) {
    // Single unit mode
    Firebase.RTDB.setString(&fbdo, "/" + String(ROOM_ID) + "/ac_command", "IDLE");
    Firebase.RTDB.setBool(&fbdo, "/" + String(ROOM_ID) + "/ac", (cmd == "ON"));
  } else {
    // Dual unit mode
    String unitPath = "/" + String(ROOM_ID) + "/units/unit_" + String(unit);
    Firebase.RTDB.setString(&fbdo, unitPath + "/ac_command", "IDLE");
    Firebase.RTDB.setBool(&fbdo, unitPath + "/ac", (cmd == "ON"));
  }
  Serial.println("✓ Firebase updated");
}

void handleIRReceiver() {
  if (irrecv.decode(&irResults)) {
    Serial.println("[IR Receiver] Signal detected!");
    String rawData = "";
    int len = irResults.rawlen;
    Serial.print("[IR Receiver] Raw length: "); Serial.println(len);

    if (len > 0 && len < 200) {
      for (int i = 0; i < len; i++) {
        if (i > 0) rawData += ",";
        rawData += String(irResults.rawbuf[i] * RAWTICK);
      }
      Serial.print("[IR Receiver] Raw data: "); Serial.println(rawData);
    }

    FirebaseJson signalJson;
    signalJson.add("rawData", rawData);
    signalJson.add("length", len);
    signalJson.add("protocol", "PANASONIC");
    signalJson.add("timestamp", String(millis()));

    Serial.println("[IR Receiver] Sending to Firebase...");
    bool success = Firebase.RTDB.setJSON(&fbdo, "/irReceiver/lastSignal", &signalJson);
    Serial.print("[IR Receiver] SetJSON success: "); Serial.println(success ? "true" : "false");
    if (!success) {
      Serial.print("[IR Receiver] Error: "); Serial.println(fbdo.errorReason());
    }

    success = Firebase.RTDB.setString(&fbdo, "/irReceiver/state", "received");
    Serial.print("[IR Receiver] SetState success: "); Serial.println(success ? "true" : "false");

    irrecv.resume();
    delay(100);
  }
}

void runAutomation(float temp, float humidity) {
  static unsigned long lastDebugLog = 0;
  if (millis() - lastDebugLog > 60000) {
    Serial.print("[Automation Debug] Humidity Enabled: "); Serial.print(automationEnabled);
    Serial.print(", Temp Enabled: "); Serial.print(temperatureAutomationEnabled);
    Serial.print(", Time since last check: "); Serial.print((millis() - lastAutomationCheckMillis) / 1000);
    Serial.println(" seconds");
    lastDebugLog = millis();
  }

  // Temperature safety automation (always runs if enabled, independent of humidity automation)
  if (temperatureAutomationEnabled) {
    if (millis() - lastAutomationCheckMillis < AUTOMATION_INTERVAL_MS) {
      return;
    }
    lastAutomationCheckMillis = millis();

    Serial.print("Temperature Safety Check - Temp: "); Serial.print(temp, 1); Serial.print("°C, Min: "); Serial.print(minTemp, 1); Serial.print("°C, Max: "); Serial.print(maxTemp, 1); Serial.println("°C");

    if (temp > maxTemp) {
      Serial.println("⚠️ TEMPERATURE SAFETY: Current temp exceeds max threshold!");
      Serial.print("Current: "); Serial.print(temp, 1); Serial.print("°C > Max: "); Serial.print(maxTemp, 1); Serial.println("°C");
      Serial.println("Action: Sending TEMP_DOWN to cool down");

      unsigned long timeSinceLastIR = millis() - lastIRSendMillis;
      if (timeSinceLastIR < IR_SEND_COOLDOWN_MS) {
        unsigned long cooldownRemaining = (IR_SEND_COOLDOWN_MS - timeSinceLastIR) / 1000;
        Serial.print("Cooldown active, "); Serial.print(cooldownRemaining); Serial.println(" seconds remaining");
        return;
      }

      uint16_t down_buf[rawTempDownLen];
      memcpy_P(down_buf, rawTempDown, sizeof(rawTempDown));
      Serial.print("Sending TEMP_DOWN on pin "); Serial.println(kIrLedPin);
      #if DUAL_UNIT_MODE
      Serial.println("Sending to Unit 1 (pin 4)");
      irsend.sendRaw(down_buf, rawTempDownLen, kFrequency);
      delay(100);
      Serial.println("Sending to Unit 2 (pin 5)");
      irsend2.sendRaw(down_buf, rawTempDownLen, kFrequency);
      #else
      irsend.sendRaw(down_buf, rawTempDownLen, kFrequency);
      #endif
      Serial.println("TEMP_DOWN sent successfully");
      lastIRSendMillis = millis();
      return;
    }

    if (temp < minTemp) {
      Serial.println("⚠️ TEMPERATURE SAFETY: Current temp below min threshold!");
      Serial.print("Current: "); Serial.print(temp, 1); Serial.print("°C < Min: "); Serial.print(minTemp, 1); Serial.println("°C");
      Serial.println("Action: Sending TEMP_UP to warm up");

      unsigned long timeSinceLastIR = millis() - lastIRSendMillis;
      if (timeSinceLastIR < IR_SEND_COOLDOWN_MS) {
        unsigned long cooldownRemaining = (IR_SEND_COOLDOWN_MS - timeSinceLastIR) / 1000;
        Serial.print("Cooldown active, "); Serial.print(cooldownRemaining); Serial.println(" seconds remaining");
        return;
      }

      uint16_t up_buf[rawTempUpLen];
      memcpy_P(up_buf, rawTempUp, sizeof(rawTempUp));
      Serial.print("Sending TEMP_UP on pin "); Serial.println(kIrLedPin);
      #if DUAL_UNIT_MODE
      Serial.println("Sending to Unit 1 (pin 4)");
      irsend.sendRaw(up_buf, rawTempUpLen, kFrequency);
      delay(100);
      Serial.println("Sending to Unit 2 (pin 5)");
      irsend2.sendRaw(up_buf, rawTempUpLen, kFrequency);
      #else
      irsend.sendRaw(up_buf, rawTempUpLen, kFrequency);
      #endif
      Serial.println("TEMP_UP sent successfully");
      lastIRSendMillis = millis();
      return;
    }
  }

  // Humidity-based automation (only runs if humidity automation is enabled)
  if (!automationEnabled) {
    return;
  }

  if (millis() - lastAutomationCheckMillis < AUTOMATION_INTERVAL_MS) {
    return;
  }
  lastAutomationCheckMillis = millis();

  Serial.print("Humidity Automation Check - Temp: "); Serial.print(temp, 1); Serial.print("°C, Humidity: "); Serial.print(humidity, 1); Serial.print("%, Min Temp: "); Serial.print(minTemp, 1); Serial.print("°C, Max Temp: "); Serial.print(maxTemp, 1); Serial.println("°C");
  Serial.print("Humidity Thresholds - Occupied: "); Serial.print(humidityOccupiedThreshold, 1); Serial.print("%, Empty: "); Serial.print(humidityEmptyThreshold, 1); Serial.println("%");

  float targetTemp;

  if (humidity > MAX_HUMIDITY) {
    targetTemp = maxTemp;
    Serial.println("📊 HUMIDITY AUTOMATION: Occupied detected");
    Serial.print("Humidity: "); Serial.print(humidity, 1); Serial.print("% > "); Serial.print(MAX_HUMIDITY); Serial.print("%, setting target to max: "); Serial.println(targetTemp, 1);
  } else if (humidity < MIN_HUMIDITY) {
    targetTemp = minTemp;
    Serial.println("📊 HUMIDITY AUTOMATION: Not occupied detected");
    Serial.print("Humidity: "); Serial.print(humidity, 1); Serial.print("% < "); Serial.print(MIN_HUMIDITY); Serial.print("%, setting target to min: "); Serial.println(targetTemp, 1);
  } else {
    Serial.println("Humidity within normal range, no humidity-based action needed");
    return;
  }

  Serial.print("Target temp: "); Serial.print(targetTemp, 1); Serial.print("°C, Current sensor temp: "); Serial.print(temp, 1); Serial.println("°C");

  if (targetTemp != temp) {
    unsigned long timeSinceLastIR = millis() - lastIRSendMillis;
    if (timeSinceLastIR < IR_SEND_COOLDOWN_MS) {
      unsigned long cooldownRemaining = (IR_SEND_COOLDOWN_MS - timeSinceLastIR) / 1000;
      Serial.print("Cooldown active, "); Serial.print(cooldownRemaining); Serial.println(" seconds remaining");
      return;
    }

    float difference = targetTemp - temp;
    int steps = (int)round(abs(difference));
    Serial.print("Adjusting temp by "); Serial.print(difference, 1); Serial.print("°C ("); Serial.print(steps); Serial.println(" steps)");
    Serial.println("Starting IR transmission...");

    for (int i = 0; i < steps; i++) {
      if (difference > 0) {
        uint16_t up_buf[rawTempUpLen];
        memcpy_P(up_buf, rawTempUp, sizeof(rawTempUp));
        Serial.print("Step "); Serial.print(i + 1); Serial.print("/"); Serial.print(steps); Serial.print(": Sending TEMP UP on pin "); Serial.println(kIrLedPin);
        #if DUAL_UNIT_MODE
        Serial.println("  -> Unit 1 (pin 4)");
        irsend.sendRaw(up_buf, rawTempUpLen, kFrequency);
        delay(100);
        Serial.println("  -> Unit 2 (pin 5)");
        irsend2.sendRaw(up_buf, rawTempUpLen, kFrequency);
        #else
        irsend.sendRaw(up_buf, rawTempUpLen, kFrequency);
        #endif
        Serial.println("TEMP UP sent");
      } else {
        uint16_t down_buf[rawTempDownLen];
        memcpy_P(down_buf, rawTempDown, sizeof(rawTempDown));
        Serial.print("Step "); Serial.print(i + 1); Serial.print("/"); Serial.print(steps); Serial.print(": Sending TEMP DOWN on pin "); Serial.println(kIrLedPin);
        #if DUAL_UNIT_MODE
        Serial.println("  -> Unit 1 (pin 4)");
        irsend.sendRaw(down_buf, rawTempDownLen, kFrequency);
        delay(100);
        Serial.println("  -> Unit 2 (pin 5)");
        irsend2.sendRaw(down_buf, rawTempDownLen, kFrequency);
        #else
        irsend.sendRaw(down_buf, rawTempDownLen, kFrequency);
        #endif
        Serial.println("TEMP DOWN sent");
      }

      if (i < steps - 1) {
        delay(20000);
      }
    }

    lastIRSendMillis = millis();
    Serial.print("Humidity automation complete. Target temp: "); Serial.println(targetTemp, 1);
  } else {
    Serial.println("Target temp matches current temp, no action needed");
  }
}